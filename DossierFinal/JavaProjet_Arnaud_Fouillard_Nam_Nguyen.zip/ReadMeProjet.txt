Pour utiliser le programme : 
	BDD:
		Il faut cr�er une base sous phpMyAdmin avec le nom javaprojet.
		Importer le script javaprojet.sql qui se trouve dans le dossier documentation.

Netbeans : 
	Il faut ajouter la library mysql li� a netbeans.
	Il faut �galement ajouter les Jar qui se trouve dans le dossier JarExterne.
	Dans la classe DbConnexion , il faut v�rifier que l'adresse de la BDD est identique ou bien la modifier si n�cessaire

Deux users diff�rents : 
	Consultation : 
		Username : Jean MDP : password
	Administration :
		Username : Pierre MDP : password
